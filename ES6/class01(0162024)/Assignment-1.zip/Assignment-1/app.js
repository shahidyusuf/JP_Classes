// Q1: Write a program in which you have to create your own biodata details are: your name, email, city,
// education, occupation, phone number, institute name etc. Using template literals and variable using let
// and const and final output is shown in document.write() same as in below:

// Output:
// Name: John Doe
// Age: 30
// Occupation: Software Developer
// Email: john.doe@example.com
// Phone Number: 123-456-7890
// Institute Name: Jawan Pakistan
// Education: ABC

// A1: 

//    let name= "Muhammad Shahid Yusuf";
//    let email= "shd.92yus@gmail.com";
//    let city= "Karachi";
//    let education= "B.COM";
//    let occupation= "Mobile Accessories Sale";
//    let number= "03002136593";
//    let institute= "Jawan Pakistan";

// document.write(`BioData <br>----------<br> Name: ${name}<br> Email: ${email}<br> City: ${city}<br>Education: ${education}
// <br> Occupation: ${occupation}<br> Phone Number: ${number}<br> Institute Name: ${institute}`)

// Q2: Write a program of a basic mark sheet using JavaScript involves let, const variables to store marks
// for different subjects and then calculating the total marks, percentage, and grade based on those marks.
// Using template literals and variable using let and const and final output is shown in document.write().

// A2:
// const totalMarks = 100;

// let math = 85;
// let science = 75;
// let computer = 90;
// let english = 88;
// let urdu = 95;

// const grandTotalMarks = math + science + computer + english + urdu;
// const percentage = (grandTotalMarks / (totalMarks * 5)) * 100;

// let grade;
// if (percentage >= 90){
//     grade = 'A';
// } else if (percentage >= 80) {
//     grade = 'B';    
// } else if (percentage >= 70) {
//     grade = 'C';    
// } else if (percentage >= 60) {
//     grade = 'D';    
// } else {
//     grade = 'F'
// }

// document.write(`Marks Sheet<br>---------------<br>Math Marks: ${math}<br>Science Marks ${science}<br>
// Computer Marks: ${computer}<br>English Marks: ${english}<br>Urdu Marks: ${urdu }<br>
// Total Marks: ${totalMarks}<br>Percentage: ${percentage.toFixed(2)}%<br>Grade: ${grade}`)

// Q3: Students using this below image you have to create each variable keyword apply at least one
// example for tasks executing. I share the output everyone must same as in the image.

// A3:
// 1.
// var a = "Shahid";

// {
//     var a = "Yusuf";
//     console.log(a)
// }
// console.log(a);
// 2.
// function foo(){
//     let a = "Shahid"
//     console.log(a)
// }
// foo()
// 3.
// const a = "Shahid";
// a = "Yusuf";
// console.log(a)

// let a = "shahid";
// a = "Yusuf";

// console.log(a)

// 4.

// var abc = "Shahid";
// var abc = "Yusuf";

// console.log(abc)

// let abc = "Shahid";
// let abc = "Yusuf";

// console.log(abc);

// 5.
// console.log(abc)
// var abc = "Shahid";
// // console.log(abc)